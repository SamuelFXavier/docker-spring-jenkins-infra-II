package com.dev.xavier.dockerSpringJenkins;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class DockerSpringJenkinsApplication {

	public static void main(String[] args) {
		SpringApplication.run(DockerSpringJenkinsApplication.class, args);
	}

}
