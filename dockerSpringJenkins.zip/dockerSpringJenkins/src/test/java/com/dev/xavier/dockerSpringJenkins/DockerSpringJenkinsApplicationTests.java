package com.dev.xavier.dockerSpringJenkins;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class DockerSpringJenkinsApplicationTests {

	@Test
	void contextLoads() {
	}

}
